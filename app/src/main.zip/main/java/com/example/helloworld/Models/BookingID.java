package com.example.helloworld.Models;


public class BookingID {

    public String id ;
    public BookingID(String id){
        this.id=id;
    }

    public String getID(){
        return this.id;
    }
}
