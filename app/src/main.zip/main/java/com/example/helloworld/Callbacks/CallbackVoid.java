package com.example.helloworld.Callbacks;

import java.util.List;

public interface CallbackVoid {
    void onSuccess();
}
